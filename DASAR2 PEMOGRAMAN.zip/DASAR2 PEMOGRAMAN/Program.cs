﻿// Hello Word! Program
using System;

namespace DasPro
{
    class Program
    {
        static void Main(string[] args)
        {
            //Deklarasi Variabel
            int kodeA;
            int kodeB;
            int kodeC;
            int jumlahkode;
            string tebakanA;
            string tebakanB;
            string tebakanC;

            int hasiltambah;
            int hasilkali;

            //Insialisasi Variabel
            kodeA = 4;
            kodeB = 8;
            kodeC = 16;

            jumlahkode= 3;

            //operasi Arimatika
            hasiltambah = kodeA+kodeB+kodeC;
            hasilkali = kodeA*kodeB*kodeC;

            //Intro
            Console.WriteLine("Anda adalah agen rahasia yang bertugas untuk mendapatkan data");
            Console.WriteLine("Akses ke server membutuhkan password yang tidak diketahui...");
            Console.WriteLine("Password terdiri dari "+jumlahkode+" angka");
            Console.WriteLine("Jika ditambahkan hasilnya "+kodeB);
            Console.WriteLine("Jika dikalikan hasilnya "+kodeC);

            //output User
            Console.Write("Masukkan kode 1 : ");
            tebakanA = Console.ReadLine();
            Console.Write("Masukkkan kode 2 : ");
            tebakanB = Console.ReadLine();
            Console.Write("Masukkan kode 3 : ");
            tebakanC = Console.ReadLine();

            Console.WriteLine("Tebakan Anda = "+tebakanA+""+tebakanB+""+tebakanC+" ?");

            //
            if(tebakanA == kodeA.ToString() && tebakanB == kodeB.ToString() && tebakanC == kodeC.ToString())
            {
                Console.WriteLine("Tebakan Anda Benar!");
            } else 
            {
                Console.WriteLine("Tebakan Anda Salah!");
            }


       }
    }
}
