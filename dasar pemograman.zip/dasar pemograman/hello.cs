
{
     
    {
        Console.WriteLine(" anda adalah agen rahasia yang bertugas mendapatkan data dari server");
        Console.WriteLine("akses ke server membutuhkan password yang tidak diketahui");
    }
}