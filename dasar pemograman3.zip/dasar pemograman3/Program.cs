﻿// Game Dadu
using System;

namespace DaduGame
{
    class program
    {
        static void Main(String[] args)
        {
            int PemainRandom;
            int KomputerRandom;

            int PoinKamu = 0;
            int KomputerPoin = 0;

            Random random = new Random();

            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Tekan tombol apa saja untuk mengulirkan dadu.");

                Console.ReadKey();


                 PemainRandom = random.Next(1, 7);
                 Console.WriteLine("Kamu Bergulir "+PemainRandom);

                 Console.WriteLine("...");
                 System.Threading.Thread.Sleep(1000);
                

                 KomputerRandom = random.Next(1, 7);
                 Console.WriteLine("Komputer Bergulir "+KomputerRandom);

                 if (PemainRandom > KomputerRandom)
                 {
                    PoinKamu++;
                    Console.WriteLine("Kamu Menang di Ronde ini!!");
                 }
                 else if ( PemainRandom < KomputerRandom)
                 {
                    KomputerPoin++;
                    Console.WriteLine("Komputer Menang di Ronde ini!!!");
                 }
                 else 
                 {
                    Console.WriteLine("Seri!!");
                 }

                 Console.WriteLine("skor saat ini");
                 Console.WriteLine("Kamu : "+PoinKamu+". Komputer : "+KomputerPoin+". ");
                 Console.WriteLine();

            }

            if (PoinKamu > KomputerPoin)
            {
                Console.WriteLine("Selamat Kamu Menang!!!");
                Console.WriteLine();
            }
            else if (PoinKamu < KomputerPoin)
            {
                Console.WriteLine("Sayang Sekali Kamu Kalah!!!");
                Console.WriteLine();
            }
            else
            {
               Console.WriteLine("Ini Seri!!"); 
            }
            Console.ReadKey();


        } 

    }
}


 
